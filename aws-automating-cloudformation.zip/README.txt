# Automating AWS with CloudFormation
A Pluralsight course teaching how to automate your cloud infrastructure on AWS with the help of AWS CloudFormation.

This repository contains examples and demos.