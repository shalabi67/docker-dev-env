A few notes about the CloudFormation template:

1. While the CF template is complete and comprehensive, it's not intended to be secure or production-worthy. It's here to help you stand up the infra I used in the course
2. It relies on an AMI that I created "ami-4c77c93f" that is only available in the eu-west-1 Region. This means you either need to create the VPC in eu-west-1 (Ireland) or use a diffrerent AMI in the "Mappings" section.
3. It creates 6 nodes - manager1, 2, 3 and node1, 2, and 3. All are running version 1.10 of the Docker Engine
4. It creates 6 subnets - 3 x management subnets and 3 x prod subnets. In reality, all 6 subnets are public subnets and share a single route table and internet gateway (making them all accessible form the internet.)

Any questions or issues, post a comment on course discussion page at Pluralsight, or ping me at nigelpoulton@hotmail.com